package com.example.apt.JNIbfcp;

public class Conference_participent {


//   bfcp_participant_information bfcpParticipantInformation = new bfcp_participant_information();
//
//    public Conference_participent(int uIP, int confID) {
//        bfcpParticipantInformation.conferenceID = confID;
//        bfcpParticipantInformation.userID = uIP;
//    }

//    public void sethello() {
//        JNIbfcpclass.bfcp_hello_participant( this);
//    }
//
//    public int gethello() {
//        return  JNIbfcpclass.bfcp_hello_participant(this);
//    }


}
