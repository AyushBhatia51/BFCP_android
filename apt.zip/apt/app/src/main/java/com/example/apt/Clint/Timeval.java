package com.example.apt.Clint;

public class Timeval {
    public int tv_sec;
    public int tv_usec;
}
