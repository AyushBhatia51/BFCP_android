package com.example.apt.Clint;

public class bfcp_digest {
    public int algorithm;     // (currently UNUSED)
    public String text;       // (currently UNUSED)

    public bfcp_digest(int algorithm, String text) {
        this.algorithm = algorithm;
        this.text = text;
    }
}
