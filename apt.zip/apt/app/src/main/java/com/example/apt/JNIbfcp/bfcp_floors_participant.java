package com.example.apt.JNIbfcp;

public class bfcp_floors_participant {

    public short floorID;			/* Floor Identifier */
    public char sInfo;				/* Status Info (text) */


}
